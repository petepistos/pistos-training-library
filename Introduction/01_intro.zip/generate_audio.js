#!/usr/bin/env node
/**
 * generate_audio.js
 *
 * Pre-generates ElevenLabs voiceover for every narrative beat in
 * intro_cybersecurity_story.html and writes the mp3 files into ./audio/.
 *
 * The story page looks for files at ./audio/{chapterId}-beat{n}.mp3
 * (e.g. ./audio/pg1-beat0.mp3). If a file exists it plays it; if not,
 * it falls back to browser TTS automatically.
 *
 * USAGE:
 *   1. Set environment variables (paste in shell, do NOT commit):
 *        $env:ELEVENLABS_API_KEY = "sk_..."
 *        $env:ELEVENLABS_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"  # default: Rachel
 *        # OR put them in a .env file (gitignored) and run with dotenv
 *
 *   2. cd into the directory containing the story HTML:
 *        cd <repo>/Introduction
 *
 *   3. Run:
 *        node generate_audio.js
 *
 *   4. Commit the resulting ./audio/ folder alongside the HTML.
 *      Total: 20 mp3 files, typically ~250-350 KB each.
 *
 * COSTS (rough, ElevenLabs Creator tier):
 *   ~20 beats × ~120 words avg × ~6 chars/word ≈ 14,400 characters
 *   Multilingual v2 model: ~30,000 chars/month included on Creator tier ($22/mo)
 *   So one full regeneration uses ~half your monthly budget.
 *   Re-run only when narration text changes.
 *
 * Re-runs are smart: if the mp3 already exists for a beat, it's skipped.
 * Delete a specific mp3 to regenerate just that one.
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const API_KEY = process.env.ELEVENLABS_API_KEY;
const VOICE_ID = process.env.ELEVENLABS_VOICE_ID || '21m00Tcm4TlvDq8ikWAM'; // Rachel default
const MODEL_ID = process.env.ELEVENLABS_MODEL_ID || 'eleven_multilingual_v2';
const STABILITY = parseFloat(process.env.ELEVENLABS_STABILITY || '0.5');
const SIMILARITY = parseFloat(process.env.ELEVENLABS_SIMILARITY || '0.75');

if (!API_KEY) {
  console.error('ERROR: ELEVENLABS_API_KEY environment variable is required.');
  console.error('PowerShell:  $env:ELEVENLABS_API_KEY = "sk_..."');
  console.error('bash/zsh:    export ELEVENLABS_API_KEY="sk_..."');
  process.exit(1);
}

// =========================================================================
// NARRATION SCRIPTS — keep in sync with intro_cybersecurity_story.html
// Each chapter id maps to an array of 4 beat texts.
// =========================================================================
const NARRATION = {
  pg1: [
    "Cybersecurity is the practice of protecting systems, networks, and the data they hold from digital attacks, theft, and damage. Every organization stores sensitive information: customer records, financial data, employee files, internal communications. Cybersecurity is the collection of technologies, policies, and human behaviors that keep that information safe. It is not just an IT concern. Every person who uses a computer, sends an email, or accesses a business system is part of an organization's security posture.",
    "Security professionals organize the goals of cybersecurity around three properties known as the CIA Triad. Confidentiality means only authorized people can read or access information. Integrity means information cannot be altered without detection — data must remain accurate and trustworthy. Availability means systems and data are accessible when needed. Every security control — every password policy, firewall, or backup system — exists to protect one or more of these three properties.",
    "Threats come from many sources: organized criminal groups seeking financial gain, individual attackers looking for easy targets, and in some cases, nation-state actors targeting industries or infrastructure. Most attacks are not targeted at a specific organization by name. Attackers scan the internet for known vulnerabilities and attack whatever is exposed. This means every organization, regardless of size, is a potential target. The organizations that get attacked are usually the ones that made themselves easy targets — through outdated systems, weak passwords, or untrained staff.",
    "Many people assume cybersecurity is something IT handles and that they have no meaningful role to play. This assumption is one of the most significant vulnerabilities in any organization. Attackers consistently exploit human behavior — clicking a malicious link, sharing a password, connecting to an unsecured network — because it is easier than breaking through technical defenses. Security awareness training exists because informed people are one of the most effective defenses an organization has.",
  ],
  pg2: [
    "Phishing is the most common method attackers use to compromise organizations. A phishing attack is a message — usually an email — designed to look legitimate and trick the recipient into doing something harmful: clicking a malicious link, opening a malware-containing attachment, or entering credentials into a fake login page. Phishing messages are carefully crafted to appear trustworthy. They may impersonate a bank, a software vendor, a government agency, or even a colleague. The goal is always the same: get the recipient to take an action they would not take if they knew the truth about the message.",
    "Malware is any software deliberately created to cause harm. It enters systems through malicious email attachments, infected downloads, compromised websites, or physical media like USB drives. Once installed, malware can take many forms: ransomware encrypts files and demands payment for their return; spyware silently records keystrokes and sends data to attackers; trojans disguise themselves as legitimate software while performing malicious functions in the background. Most malware is designed to be invisible — victims often do not know they are infected until significant damage has occurred.",
    "Passwords remain one of the primary mechanisms for controlling access to systems and data, and they remain one of the most consistently exploited weaknesses. Attackers use automated tools that test millions of common passwords per second. They also use credential stuffing — taking username and password combinations stolen from one breached service and trying them against banking sites, email accounts, and business systems. If you use the same password across multiple services, one breach anywhere exposes you everywhere. Strong, unique passwords — and multifactor authentication — dramatically reduce this exposure.",
    "Social engineering attacks exploit human psychology rather than software vulnerabilities. An attacker might call an employee pretending to be IT support and ask for their login credentials to fix an issue. They might impersonate a vendor requesting urgent payment. They might create a sense of urgency to pressure someone into acting without thinking. These attacks work because they exploit the same traits that make people good employees: helpfulness, trust in authority, and willingness to act quickly. Recognizing social engineering requires healthy skepticism about unsolicited requests.",
  ],
  pg3: [
    "Before launching an attack, adversaries typically research their target. This reconnaissance phase can be passive — reviewing a company's website, LinkedIn profiles, and public records to identify employees, technology vendors, and business relationships. It can also be active — scanning the organization's internet-facing systems for open ports and known vulnerabilities. The information gathered shapes every subsequent phase of the attack. Organizations that limit what they expose publicly and monitor their attack surface are harder targets from the start.",
    "An attacker gains initial access through the weakest point available to them. In most cases, that weakest point is a person, not a system. A phishing email that tricks an employee into entering their credentials gives the attacker a valid username and password for legitimate use of the organization's systems. An unpatched vulnerability in a public-facing application gives a technical entry point. Once inside, the attacker typically operates using legitimate credentials and tools, making their presence difficult to distinguish from normal user activity.",
    "After gaining initial access, attackers rarely stop at one account or one system. They move laterally — using the access they have to discover and gain access to additional systems, credentials, and data. An attacker who compromises a single email account may find password reset links, internal system names, or vendor communications that allow them to expand their foothold. Segmentation — dividing networks and limiting what each account can access — limits how far an attacker can move. The principle of least privilege is a direct countermeasure to lateral movement.",
    "The impact phase is when an attacker achieves their objective — and when the organization first becomes aware something is wrong. For ransomware, the impact is sudden: files become encrypted and a ransom demand appears. For data theft, the impact may not be apparent for months — until stolen data appears for sale or is used in fraud. For business email compromise, the impact is a fraudulent wire transfer that is often discovered only when the legitimate recipient asks why payment has not arrived. Understanding that attacks follow a process — and can be interrupted at any phase — underscores why layered defenses matter.",
  ],
  pg4: [
    "Multifactor authentication, or MFA, requires a user to provide two or more verification factors to access a system: something they know — a password; something they have — a phone or hardware token; or something they are — a fingerprint or face scan. MFA is one of the highest-impact security controls available. Even if an attacker obtains a valid username and password through phishing or a data breach, they cannot complete login without the second factor. Organizations that deploy MFA on all user accounts eliminate the majority of credential-based attacks.",
    "Software vulnerabilities are flaws in programs that attackers can exploit to gain unauthorized access or execute malicious code. Vendors release security patches when vulnerabilities are discovered, and attackers closely track which patches have been released — because they know unpatched systems remain vulnerable. Organizations that delay applying patches give attackers a window of opportunity that can last months or years. Enabling automatic updates and establishing a process for testing and deploying patches quickly removes a significant portion of the attack surface.",
    "No set of defenses is perfect. Backups are the recovery mechanism of last resort — and one of the most important security investments any organization can make. A reliable backup system means that a ransomware attack, a hardware failure, or an accidental deletion does not result in permanent data loss. Effective backups follow the 3-2-1 rule: keep three copies of data, on two different media types, with one copy stored offsite or in a separate cloud environment. Critically, backups must be tested regularly. An untested backup is not a backup — it is an assumption.",
    "Technology controls are essential, but they are not sufficient. Attackers consistently exploit human behavior because it is easier than overcoming technical defenses. Security awareness training equips every person to recognize threats, make better decisions, and respond appropriately when something seems wrong. Key behaviors include verifying unexpected requests through a separate channel before acting, reporting suspicious emails rather than deleting them, following password policies and using a password manager, and knowing who to contact when something appears wrong.",
  ],
  pg5: [
    "The CIA Triad defines the three core goals of security. Confidentiality keeps information accessible only to authorized parties. Integrity ensures information cannot be altered without detection. Availability ensures systems remain accessible when needed. Every security control exists to protect one or more of these properties.",
    "Phishing, social engineering, weak passwords, and malware delivered through human action account for the majority of successful attacks. Understanding these threat types — and recognizing the tactics attackers use — is the foundation of effective security behavior.",
    "Reconnaissance, initial access, lateral movement, and impact define the attack lifecycle. Defenses at each stage — limiting exposed information, deploying MFA, segmenting networks, monitoring for anomalies — can interrupt an attack before it reaches the impact phase.",
    "Multifactor authentication, timely patching, reliable backups, and security awareness training are consistently the most effective defenses. Organizations that implement these four controls address the methods used in the overwhelming majority of successful cyberattacks.",
  ],
};

// =========================================================================
// ElevenLabs API call
// =========================================================================
function generateMp3(text, outPath) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      text: text,
      model_id: MODEL_ID,
      voice_settings: {
        stability: STABILITY,
        similarity_boost: SIMILARITY,
      },
    });

    const req = https.request(
      {
        hostname: 'api.elevenlabs.io',
        path: `/v1/text-to-speech/${VOICE_ID}`,
        method: 'POST',
        headers: {
          'xi-api-key': API_KEY,
          'Content-Type': 'application/json',
          'Accept': 'audio/mpeg',
          'Content-Length': Buffer.byteLength(body),
        },
      },
      (res) => {
        if (res.statusCode !== 200) {
          let errBody = '';
          res.on('data', (chunk) => (errBody += chunk));
          res.on('end', () =>
            reject(new Error(`HTTP ${res.statusCode}: ${errBody}`))
          );
          return;
        }
        const out = fs.createWriteStream(outPath);
        res.pipe(out);
        out.on('finish', () => out.close(() => resolve()));
        out.on('error', reject);
      }
    );

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// =========================================================================
// Main
// =========================================================================
async function main() {
  const audioDir = path.resolve(process.cwd(), 'audio');
  if (!fs.existsSync(audioDir)) fs.mkdirSync(audioDir, { recursive: true });

  console.log(`Output dir: ${audioDir}`);
  console.log(`Voice ID:   ${VOICE_ID}`);
  console.log(`Model:      ${MODEL_ID}`);
  console.log('');

  let totalGenerated = 0;
  let totalSkipped = 0;
  let totalChars = 0;

  for (const [chapterId, beats] of Object.entries(NARRATION)) {
    for (let i = 0; i < beats.length; i++) {
      const filename = `${chapterId}-beat${i}.mp3`;
      const outPath = path.join(audioDir, filename);
      const text = beats[i];

      if (fs.existsSync(outPath)) {
        console.log(`  SKIP ${filename} (exists, ${(fs.statSync(outPath).size / 1024).toFixed(0)} KB)`);
        totalSkipped++;
        continue;
      }

      process.stdout.write(`  GEN  ${filename} (${text.length} chars)... `);
      try {
        await generateMp3(text, outPath);
        const kb = (fs.statSync(outPath).size / 1024).toFixed(0);
        console.log(`done (${kb} KB)`);
        totalGenerated++;
        totalChars += text.length;
      } catch (e) {
        console.log(`FAILED: ${e.message}`);
        // Don't bail — keep going so partial regen still works
      }
    }
  }

  console.log('');
  console.log(`Generated: ${totalGenerated} files (${totalChars.toLocaleString()} characters)`);
  console.log(`Skipped:   ${totalSkipped} files (already present)`);
  console.log('');
  console.log('Done. Commit the audio/ folder alongside intro_cybersecurity_story.html.');
}

main().catch((e) => {
  console.error('FATAL:', e);
  process.exit(1);
});
